<script setup lang="ts"></script>

<template>
  <div>
    <BaseNavigation />
    <slot />
  </div>
</template>
