export default defineNuxtRouteMiddleware((to, from) => {
  // console.log("page change", from);
});
